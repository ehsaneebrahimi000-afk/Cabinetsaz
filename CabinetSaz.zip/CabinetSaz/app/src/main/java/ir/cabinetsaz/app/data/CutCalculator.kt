package ir.cabinetsaz.app.data

/** Initial carcass cut estimate. All dimensions are millimetres. Verify construction details before cutting. */
data class CutInput(
    val width: Int,
    val height: Int,
    val depth: Int,
    val thickness: Int,
    val shelfCount: Int,
    val doorCount: Int,
    val includeBack: Boolean,
    val backThickness: Int = 3,
    val doorGap: Int = 2
)

data class CutPart(val name: String, val widthMm: Int, val heightMm: Int, val quantity: Int) {
    val areaSquareMetres: Double
        get() = widthMm.toDouble() * heightMm * quantity / 1_000_000.0
}

data class CutResult(
    val parts: List<CutPart>,
    val totalAreaSquareMetres: Double,
    val totalPieces: Int,
    val edgeBandingMetres: Double,
    val estimatedHinges: Int
)

object CutCalculator {
    fun calculate(input: CutInput): CutResult? {
        val w = input.width
        val h = input.height
        val d = input.depth
        val t = input.thickness
        if (w <= 0 || h <= 0 || d <= 0 || t !in 8..40) return null
        if (w <= 2 * t || h <= 2 * t || d <= 0) return null
        if (input.shelfCount !in 0..30 || input.doorCount !in 0..4) return null
        if (input.backThickness !in 2..10 || input.doorGap !in 0..8) return null

        val innerWidth = w - 2 * t
        val parts = mutableListOf(
            CutPart("پهلو", d, h, 2),
            CutPart("کف", innerWidth, d, 1),
            CutPart("سقف", innerWidth, d, 1)
        )
        if (input.shelfCount > 0) parts += CutPart("طبقه", innerWidth, d, input.shelfCount)
        if (input.includeBack) parts += CutPart("پشت‌بند", w, h, 1)

        if (input.doorCount > 0) {
            val totalGap = input.doorGap * (input.doorCount + 1)
            val doorWidth = (w - totalGap) / input.doorCount
            if (doorWidth <= 0) return null
            parts += CutPart("درب (خام؛ قبل از لقی نهایی نصب)", doorWidth, h, input.doorCount)
        }

        val area = parts.sumOf { it.areaSquareMetres }
        val edgeMm = parts.sumOf { part ->
            // Approximate exposed front edges: sides, horizontal panels/shelves and doors.
            when (part.name) {
                "پهلو" -> h.toLong() * part.quantity
                "کف", "سقف", "طبقه" -> part.widthMm.toLong() * part.quantity
                "درب (خام؛ قبل از لقی نهایی نصب)" -> (2L * (part.widthMm + part.heightMm)) * part.quantity
                else -> 0L
            }
        }
        val hinges = if (input.doorCount == 0) 0 else input.doorCount * when {
            h <= 900 -> 2
            h <= 1600 -> 3
            h <= 2100 -> 4
            else -> 5
        }
        return CutResult(parts, area, parts.sumOf { it.quantity }, edgeMm / 1000.0, hinges)
    }
}
