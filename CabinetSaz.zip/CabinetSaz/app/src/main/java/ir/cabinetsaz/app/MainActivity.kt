package ir.cabinetsaz.app

import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import ir.cabinetsaz.app.data.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = CabinetDatabase.get(this).cabinetDao()
        setContent { CabinetSazApp(dao) }
    }
}

private enum class Page(val title: String) { HOME("خانه"), PROJECTS("پروژه‌ها"), DESIGNER("طراحی ۳بعدی"), LAYOUT("چیدمان"), CALCULATOR("محاسبات"), MATERIALS("متریال"), WORKSHOP("کارگاه"), ROOM("فضای آشپزخانه") }
private val gold = androidx.compose.ui.graphics.Color(0xFFD4AF37)
private val dark = androidx.compose.ui.graphics.Color(0xFF101012)
private fun money(value: Long) = NumberFormat.getNumberInstance(Locale("fa", "IR")).format(value) + " تومان"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CabinetSazApp(dao: CabinetDao) {
    var page by remember { mutableStateOf(Page.HOME) }
    val projects by dao.observeProjects().collectAsState(initial = emptyList())
    val materials by dao.observeMaterials().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
  val context = androidx.compose.ui.platform.LocalContext.current
  val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
    if (uri != null) scope.launch {
      val json = JSONObject().put("app", "CabinetSaz").put("schemaVersion", 1)
        .put("exportedAt", System.currentTimeMillis())
        .put("projects", JSONArray().apply { projects.forEach { p -> put(JSONObject().put("title",p.title).put("customer",p.customer).put("widthMm",p.widthMm).put("heightMm",p.heightMm).put("depthMm",p.depthMm).put("notes",p.notes).put("createdAt",p.createdAt)) } })
        .put("materials", JSONArray().apply { materials.forEach { m -> put(JSONObject().put("name",m.name).put("category",m.category).put("unitPrice",m.unitPrice).put("unit",m.unit)) } })
      runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json.toString(2)) } }
    }
  }
    MaterialTheme(colorScheme = darkColorScheme(primary = gold, background = dark, surface = androidx.compose.ui.graphics.Color(0xFF1B1B20), onPrimary = dark)) {
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(containerColor = dark,
          topBar = { TopAppBar(title = { Column { Text("کابینت ساز", fontWeight = FontWeight.Black); Text("دستیار آفلاین کابینت‌سازی", style = MaterialTheme.typography.labelSmall) } }, navigationIcon = { Icon(Icons.Default.Carpenter, null, Modifier.padding(horizontal = 14.dp), tint = gold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = dark)) },
          bottomBar = { NavigationBar(containerColor = androidx.compose.ui.graphics.Color(0xFF19191D)) {
            listOf(Page.HOME, Page.PROJECTS, Page.DESIGNER, Page.LAYOUT, Page.CALCULATOR, Page.MATERIALS, Page.WORKSHOP).forEach { p ->
              val icon = when(p) { Page.HOME -> Icons.Default.Home; Page.PROJECTS -> Icons.Default.Folder; Page.DESIGNER -> Icons.Default.ViewInAr; Page.LAYOUT -> Icons.Default.Dashboard; Page.CALCULATOR -> Icons.Default.Calculate; Page.MATERIALS -> Icons.Default.Widgets; Page.WORKSHOP -> Icons.Default.Handyman; Page.ROOM -> Icons.Default.Home }
              NavigationBarItem(selected = page == p, onClick = { page = p }, icon = { Icon(icon, null) }, label = { Text(p.title) })
            }
          } }
        ) { padding ->
          Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
            when(page) {
              Page.HOME -> HomeScreen(projects.size, materials.size, onGo = { page = it }, onBackup = { backupLauncher.launch("cabinet-saz-backup.json") })
              Page.PROJECTS -> ProjectsScreen(projects, onAdd = { page = Page.CALCULATOR }, onDelete = { id -> scope.launch { dao.deleteProject(id) } })
              Page.DESIGNER -> CabinetDesignerScreen()
              Page.LAYOUT -> KitchenLayoutScreen()
              Page.ROOM -> RoomPlanScreen()
              Page.CALCULATOR -> CalculatorScreen(onSave = { p -> scope.launch { dao.insertProject(p); page = Page.PROJECTS } })
              Page.MATERIALS -> MaterialsScreen(materials, onAdd = { item -> scope.launch { dao.insertMaterial(item) } }, onDelete = { id -> scope.launch { dao.deleteMaterial(id) } })
              Page.WORKSHOP -> WorkshopScreen()
            }
          }
        }
      }
    }
}

@Composable private fun HomeScreen(projectCount: Int, materialCount: Int, onGo: (Page) -> Unit, onBackup: () -> Unit) {
  Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(13.dp)) {
    Spacer(Modifier.height(4.dp))
    Text("همه ابزارهای کارگاه، در یک‌جا", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      MetricCard("پروژه‌ها", projectCount.toString(), Modifier.weight(1f)); MetricCard("متریال‌ها", materialCount.toString(), Modifier.weight(1f))
    }
    HomeAction("طراحی سه‌بعدی کابینت", "چرخش مدل، بازکردن درب‌ها و بیرون‌کشیدن کشوها", Icons.Default.ViewInAr) { onGo(Page.DESIGNER) }
    HomeAction("چیدمان آزاد آشپزخانه", "افزودن، جابه‌جایی و ویرایش یونیت‌ها در نمای بالا", Icons.Default.Dashboard) { onGo(Page.LAYOUT) }
    HomeAction("نقشه فضای آشپزخانه", "ابعاد اتاق، در، پنجره، سینک، اجاق و بررسی تداخل", Icons.Default.Home) { onGo(Page.ROOM) }
    HomeAction("ثبت پروژه و محاسبه قطعات", "ابعاد، ضخامت ورق و لیست برش اولیه", Icons.Default.AddBox) { onGo(Page.CALCULATOR) }
    HomeAction("مدیریت پروژه‌ها", "مشاهده و حذف پروژه‌های ذخیره‌شده", Icons.Default.Folder) { onGo(Page.PROJECTS) }
    HomeAction("کتابخانه متریال و قیمت", "ثبت MDF، نوار PVC و یراق‌آلات", Icons.Default.Widgets) { onGo(Page.MATERIALS) }
    HomeAction("چک‌لیست کارگاه", "مراحل اندازه‌گیری تا تحویل", Icons.Default.Checklist) { onGo(Page.WORKSHOP) }
    OutlinedButton(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Spacer(Modifier.width(8.dp)); Text("خروجی پشتیبان پروژه‌ها و متریال‌ها (JSON)") }
    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFF24221A))) { Column(Modifier.padding(14.dp)) { Text("حالت کاملاً آفلاین", color = gold, fontWeight = FontWeight.Bold); Text("اطلاعات روی همین گوشی ذخیره می‌شود. برای جلوگیری از ازدست‌رفتن اطلاعات، از فایل دیتابیس در تنظیمات اندروید نسخه پشتیبان تهیه کنید.", style = MaterialTheme.typography.bodySmall) } }
    Text("یادآوری: محاسبات فعلی برای برآورد اولیه‌اند و پیش از برش باید با نقشه اجرایی، نوع اتصال و اندازه‌گیری محل کنترل شوند.", style = MaterialTheme.typography.bodySmall)
  }
}

@Composable private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) { Card(modifier, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFF202025))) { Column(Modifier.padding(15.dp)) { Text(title); Text(value, color = gold, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) } } }
@Composable private fun HomeAction(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) { Card(onClick = click, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFF202025))) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = gold, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp)); Column { Text(title, fontWeight = FontWeight.Bold); Text(sub, style = MaterialTheme.typography.bodySmall) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronLeft, null) } } }

@Composable private fun ProjectsScreen(projects: List<CabinetProject>, onAdd: () -> Unit, onDelete: (Long) -> Unit) {
  Column(Modifier.fillMaxSize()) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) { Text("پروژه‌های ذخیره‌شده", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("پروژه جدید") } }
    if(projects.isEmpty()) EmptyMessage("هنوز پروژه‌ای ثبت نشده است. از بخش محاسبات، ابعاد پروژه را وارد و ذخیره کنید.")
    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) { items(projects, key = { it.id }) { p -> Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFF202025))) { Column(Modifier.padding(14.dp)) { Text(p.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium); Text("مشتری: ${p.customer.ifBlank { "ثبت نشده" }}"); Text("ابعاد کلی: ${p.widthMm} × ${p.heightMm} × ${p.depthMm} میلی‌متر"); if(p.notes.isNotBlank()) Text(p.notes, style = MaterialTheme.typography.bodySmall); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = { onDelete(p.id) }) { Icon(Icons.Default.Delete, null); Text("حذف") } } } } } }
  }
}

@Composable private fun CalculatorScreen(onSave: (CabinetProject) -> Unit) {
  val context = androidx.compose.ui.platform.LocalContext.current
  var pendingCsvUri by remember { mutableStateOf<Uri?>(null) }
  val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri -> pendingCsvUri = uri }
  var name by remember { mutableStateOf("") }; var customer by remember { mutableStateOf("") }
  var width by remember { mutableStateOf("600") }; var height by remember { mutableStateOf("720") }; var depth by remember { mutableStateOf("560") }; var thickness by remember { mutableStateOf("16") }; var shelves by remember { mutableStateOf("1") }; var doors by remember { mutableStateOf("2") }; var back by remember { mutableStateOf(true) }; var notes by remember { mutableStateOf("") }
  val w=width.toIntOrNull() ?: 0; val h=height.toIntOrNull() ?: 0; val d=depth.toIntOrNull() ?: 0; val t=thickness.toIntOrNull() ?: 16; val sh=(shelves.toIntOrNull() ?: 0).coerceIn(0,20); val dr=(doors.toIntOrNull() ?: 0).coerceIn(0,8)
  val cutResult = CutCalculator.calculate(CutInput(w,h,d,t,sh,dr,back))
  LaunchedEffect(pendingCsvUri, cutResult) {
    val uri = pendingCsvUri
    val result = cutResult
    if (uri != null && result != null) {
      runCatching {
        val csv = buildString {
          append("\uFEFFنام قطعه,عرض (mm),ارتفاع (mm),تعداد\r\n")
          result.parts.forEach { append("\"${it.name}\",${it.widthMm},${it.heightMm},${it.quantity}\r\n") }
          append("مساحت کل (m2),${String.format(Locale.US, "%.3f", result.totalAreaSquareMetres)}\r\n")
          append("نوار لبه تقریبی (m),${String.format(Locale.US, "%.2f", result.edgeBandingMetres)}\r\n")
          append("لولای پیشنهادی,${result.estimatedHinges}\r\n")
        }
        context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(csv) }
      }
      pendingCsvUri = null
    }
  }
  val valid = cutResult != null
  Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
    Text("محاسبه‌گر و لیست برش اولیه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("ابعاد را به میلی‌متر وارد کنید.", style = MaterialTheme.typography.bodySmall)
    Field(name,{name=it},"نام پروژه *"); Field(customer,{customer=it},"نام مشتری")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Field(width,{width=it.digits()},"عرض",Modifier.weight(1f)); Field(height,{height=it.digits()},"ارتفاع",Modifier.weight(1f)); Field(depth,{depth=it.digits()},"عمق",Modifier.weight(1f)) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Field(thickness,{thickness=it.digits()},"ضخامت ورق",Modifier.weight(1f)); Field(shelves,{shelves=it.digits()},"تعداد طبقه",Modifier.weight(1f)); Field(doors,{doors=it.digits()},"تعداد درب",Modifier.weight(1f)) }
    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(back,{back=it}); Text("محاسبه یک پشت‌بند") }
    Field(notes,{notes=it},"یادداشت پروژه")
    Card(colors=CardDefaults.cardColors(containerColor= androidx.compose.ui.graphics.Color(0xFF202025))) { Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) {
      Text("لیست قطعات محاسبه‌شده", fontWeight=FontWeight.Bold, color=gold)
      if(cutResult != null) cutResult.parts.forEach { part -> Text("${part.name}: ${part.widthMm} × ${part.heightMm} میلی‌متر — ${part.quantity} عدد") } else Text("ابعاد، ضخامت یا تعداد قطعات معتبر نیست.")
      Divider()
      if(cutResult != null) {
        Text("مساحت مجموع قطعات: ${"%.3f".format(Locale.US,cutResult.totalAreaSquareMetres)} مترمربع")
        Text("تعداد کل قطعات: ${cutResult.totalPieces}")
        Text("نوار لبه تقریبی: ${"%.2f".format(Locale.US,cutResult.edgeBandingMetres)} متر")
        Text("تعداد لولای پیشنهادی: ${cutResult.estimatedHinges} عدد")
      }
      if (cutResult != null) OutlinedButton(onClick = { csvLauncher.launch("cut-list-${name.ifBlank { "cabinet" }}.csv") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Text("خروجی لیست برش CSV") }
      Text("هشدار: این فقط برآورد اولیه بدنه است؛ لقی نصب، شیار پشت، نوع اتصال، جهت رگه، پایه و جزئیات سازه‌ای را قبل از برش جداگانه کنترل کنید.", style=MaterialTheme.typography.bodySmall)
    } }
    Button(onClick={onSave(CabinetProject(title=name.trim(),customer=customer.trim(),widthMm=w,heightMm=h,depthMm=d,notes=notes))}, enabled=name.isNotBlank() && valid, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Save,null); Text("ذخیره پروژه روی گوشی") }
    Spacer(Modifier.height(8.dp))
  }
}

@Composable private fun MaterialsScreen(materials: List<MaterialItem>, onAdd: (MaterialItem)->Unit, onDelete:(Long)->Unit) {
  var show by remember { mutableStateOf(false) }
  Column(Modifier.fillMaxSize()) { Row(Modifier.fillMaxWidth().padding(vertical=12.dp), verticalAlignment=Alignment.CenterVertically) { Text("کتابخانه متریال",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); Button(onClick={show=true}) { Icon(Icons.Default.Add,null); Text("افزودن") } }
    if(materials.isEmpty()) EmptyMessage("هنوز متریالی ثبت نشده است. نام، دسته، واحد و قیمت خرید را وارد کنید.")
    LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) { items(materials,key={it.id}) { m -> Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=androidx.compose.ui.graphics.Color(0xFF202025))) { Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(m.name,fontWeight=FontWeight.Bold); Text("${m.category} • ${m.unit}",style=MaterialTheme.typography.bodySmall); Text(money(m.unitPrice),color=gold) }; IconButton(onClick={onDelete(m.id)}) { Icon(Icons.Default.Delete,null) } } } } }
  }
  if(show) MaterialDialog(onDismiss={show=false},onSave={onAdd(it);show=false})
}

@Composable private fun MaterialDialog(onDismiss:()->Unit,onSave:(MaterialItem)->Unit) {
  var name by remember { mutableStateOf("") }; var category by remember { mutableStateOf("MDF") }; var price by remember { mutableStateOf("0") }; var unit by remember { mutableStateOf("ورق") }
  AlertDialog(onDismissRequest=onDismiss,title={Text("متریال جدید")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { Field(name,{name=it},"نام متریال"); Field(category,{category=it},"دسته (MDF، PVC، یراق...)"); Field(price,{price=it.digits()},"قیمت واحد به تومان"); Field(unit,{unit=it},"واحد") }},confirmButton={TextButton(onClick={onSave(MaterialItem(name=name.trim(),category=category.trim(),unitPrice=price.toLongOrNull()?:0,unit=unit.trim()))},enabled=name.isNotBlank()) { Text("ذخیره") }},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable private fun WorkshopScreen() {
  val context = androidx.compose.ui.platform.LocalContext.current
  val prefs = remember { context.getSharedPreferences("workshop_checklist_v1", android.content.Context.MODE_PRIVATE) }
  val tasks=listOf("بازدید و اندازه‌گیری محل","ثبت محل پنجره، در و تأسیسات","نهایی‌کردن طرح با مشتری","تأیید رنگ و نوع متریال","تهیه ورق و یراق‌آلات","برش قطعات","لبه‌چسبانی و سوراخ‌کاری","مونتاژ بدنه و نصب یراق","کنترل کیفیت و بسته‌بندی","حمل و نصب در محل","تحویل نهایی و تسویه")
  val checked= remember { mutableStateMapOf<Int,Boolean>().apply { tasks.indices.forEach { i -> if (prefs.getBoolean("task_$i", false)) put(i, true) } } }
  Column(Modifier.fillMaxSize()) { Text("چک‌لیست مراحل کارگاه",Modifier.padding(vertical=12.dp),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold); val done=checked.values.count{it}; LinearProgressIndicator(progress={done.toFloat()/tasks.size},modifier=Modifier.fillMaxWidth(),color=gold); Text("$done از ${tasks.size} مرحله انجام شده",style=MaterialTheme.typography.bodySmall); LazyColumn { items(tasks.size) { i -> Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically) { Checkbox(checked[i]==true,onCheckedChange={ checked[i]=it; prefs.edit().putBoolean("task_$i", it).apply() }); Text(tasks[i]) } } }; Text("وضعیت چک‌لیست روی همین گوشی ذخیره می‌شود.",style=MaterialTheme.typography.bodySmall) }
}

@Composable private fun Field(value:String,onValue:(String)->Unit,label:String,modifier:Modifier=Modifier.fillMaxWidth()) { OutlinedTextField(value,onValue,label={Text(label)},modifier=modifier,singleLine=true) }
@Composable private fun EmptyMessage(message:String) { Box(Modifier.fillMaxWidth().padding(24.dp),contentAlignment=Alignment.Center) { Text(message,style=MaterialTheme.typography.bodyMedium) } }
private fun String.digits() = filter { it.isDigit() }
