package ir.cabinetsaz.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class CabinetProject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val customer: String = "",
    val widthMm: Int = 0,
    val heightMm: Int = 0,
    val depthMm: Int = 0,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "materials")
data class MaterialItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val unitPrice: Long = 0,
    val unit: String = "عدد"
)
