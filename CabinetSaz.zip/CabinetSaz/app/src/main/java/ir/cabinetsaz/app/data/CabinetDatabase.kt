package ir.cabinetsaz.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [CabinetProject::class, MaterialItem::class], version = 1, exportSchema = false)
abstract class CabinetDatabase : RoomDatabase() {
    abstract fun cabinetDao(): CabinetDao
    companion object {
        @Volatile private var INSTANCE: CabinetDatabase? = null
        fun get(context: Context): CabinetDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, CabinetDatabase::class.java, "cabinet_saz.db").build().also { INSTANCE = it }
        }
    }
}
