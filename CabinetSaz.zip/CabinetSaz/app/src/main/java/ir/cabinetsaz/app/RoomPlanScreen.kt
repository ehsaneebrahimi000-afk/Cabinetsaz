package ir.cabinetsaz.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

private data class RoomItem(val id: Long, val name: String, val kind: String, val x: Float, val y: Float, val width: Int, val depth: Int)
private data class RoomConfig(val width: Int = 3600, val depth: Int = 3000, val shape: String = "مستطیلی")

@Composable
fun RoomPlanScreen() {
    val context = LocalContext.current
    val density = LocalDensity.current.density
    var config by remember { mutableStateOf(loadRoomConfig(context)) }
    var itemsState by remember { mutableStateOf(loadRoomItems(context)) }
    var selected by remember { mutableStateOf<Long?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showSize by remember { mutableStateOf(false) }
    val latest by rememberUpdatedState(itemsState)
    val active = itemsState.firstOrNull { it.id == selected }
    fun update(next: List<RoomItem>) { itemsState = next; saveRoomItems(context, next) }
    val collisions = remember(itemsState) { findRoomCollisions(itemsState) }
    val outOfBounds = remember(itemsState, config) { itemsState.filter { it.x < 0f || it.y < 0f || it.x + it.width > config.width || it.y + it.depth > config.depth } }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("نقشه فضای آشپزخانه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("دیوار، در، پنجره و محل تجهیزات • ذخیره آفلاین", style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Text("افزودن") }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202025))) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${config.width} × ${config.depth} میلی‌متر", Modifier.weight(1f), color = Color(0xFFD4AF37), fontWeight = FontWeight.Bold)
                    TextButton(onClick = { showSize = true }) { Text("ابعاد فضا") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("مستطیلی", "L شکل", "U شکل").forEach { shape ->
                        FilterChip(selected = config.shape == shape, onClick = { config = config.copy(shape = shape); saveRoomConfig(context, config) }, label = { Text(shape) })
                    }
                }
                BoxWithConstraints(Modifier.fillMaxWidth().height(300.dp).background(Color(0xFF121216), RoundedCornerShape(9.dp)).padding(12.dp)) {
                    val scale = minOf((maxWidth.value - 24f) / config.width, (maxHeight.value - 24f) / config.depth).coerceAtLeast(.025f)
                    val roomW = (config.width * scale).dp
                    val roomH = (config.depth * scale).dp
                    Box(Modifier.size(roomW, roomH).align(Alignment.Center).border(3.dp, Color(0xFFD4AF37), RoundedCornerShape(2.dp))) {
                        // L/U are shown as wall-plan guides; editable objects remain in the same room coordinate system.
                        if (config.shape != "مستطیلی") Box(Modifier.align(Alignment.BottomStart).width(18.dp).fillMaxHeight().background(Color(0xFF51452E)))
                        if (config.shape == "U شکل") Box(Modifier.align(Alignment.BottomEnd).width(18.dp).fillMaxHeight().background(Color(0xFF51452E)))
                        itemsState.forEach { item ->
                            val selectedNow = item.id == selected
                            val w = (item.width * scale).coerceAtLeast(13f).dp
                            val h = (item.depth * scale).coerceAtLeast(13f).dp
                            Box(Modifier.offset { IntOffset((item.x * scale * density).roundToInt(), (item.y * scale * density).roundToInt()) }
                                .size(w, h)
                                .background(itemColor(item.kind, selectedNow), RoundedCornerShape(4.dp))
                                .border(if (selectedNow) 2.dp else 1.dp, if (selectedNow) Color.White else Color(0xFFB9B9B9), RoundedCornerShape(4.dp))
                                .clickable { selected = item.id }
                                .pointerInput(item.id, scale) {
                                    detectDragGestures { change, drag ->
                                        change.consume()
                                        val nx = (item.x + drag.x / (scale * density)).coerceIn(0f, (config.width - item.width).coerceAtLeast(0).toFloat())
                                        val ny = (item.y + drag.y / (scale * density)).coerceIn(0f, (config.depth - item.depth).coerceAtLeast(0).toFloat())
                                        update(latest.map { if (it.id == item.id) it.copy(x = nx, y = ny) else it }); selected = item.id
                                    }
                                }, contentAlignment = Alignment.Center) {
                                Text(item.name, color = Color.White, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                            }
                        }
                    }
                }
                Text("مستطیل‌ها قابل انتخاب و جابه‌جایی هستند. مقیاس نقشه براساس ابعاد واقعی فضا تنظیم می‌شود.", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (outOfBounds.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF493A22))) {
                Column(Modifier.padding(10.dp)) {
                    Text("هشدار خارج از محدوده اتاق (${outOfBounds.size})", color = Color(0xFFFFD180), fontWeight = FontWeight.Bold)
                    outOfBounds.take(4).forEach { Text("${it.name} از مرز فضای تعریف‌شده بیرون است.", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        if (collisions.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF492727))) {
                Column(Modifier.padding(10.dp)) {
                    Text("هشدار تداخل (${collisions.size})", color = Color(0xFFFFB4AB), fontWeight = FontWeight.Bold)
                    collisions.take(5).forEach { Text("${it.first} با ${it.second} هم‌پوشانی دارد.", style = MaterialTheme.typography.bodySmall) }
                }
            }
        } else Text("تداخل ثبت‌شده‌ای بین اجزای نقشه وجود ندارد.", color = Color(0xFF9CCC9C), style = MaterialTheme.typography.bodySmall)
        if (active != null) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202025))) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(active.name, fontWeight = FontWeight.Bold); Text("${active.kind} • ${active.width} × ${active.depth} mm", style = MaterialTheme.typography.bodySmall) }
                    IconButton(onClick = { update(itemsState.filterNot { it.id == active.id }); selected = null }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFE57373)) }
                }
            }
        }
        Text("اجزای فضا (${itemsState.size})", fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(itemsState, key = { it.id }) { item ->
                TextButton(onClick = { selected = item.id }, modifier = Modifier.fillMaxWidth()) {
                    Text("${item.name} • ${item.kind} • موقعیت ${item.x.toInt()}, ${item.y.toInt()} mm", Modifier.weight(1f))
                }
            }
        }
    }
    if (showAdd) AddRoomItemDialog(onDismiss = { showAdd = false }) { name, kind, width, depth ->
        val next = RoomItem(System.currentTimeMillis(), name, kind, 30f, 30f, width, depth)
        update(itemsState + next); selected = next.id; showAdd = false
    }
    if (showSize) RoomSizeDialog(config, onDismiss = { showSize = false }) { w, d ->
        config = config.copy(width = w, depth = d); saveRoomConfig(context, config)
        update(itemsState.map { it.copy(x = it.x.coerceAtMost((w-it.width).coerceAtLeast(0).toFloat()), y = it.y.coerceAtMost((d-it.depth).coerceAtLeast(0).toFloat())) })
        showSize = false
    }
}

private fun itemColor(kind: String, selected: Boolean): Color = when {
    selected -> Color(0xFFB58B24)
    kind == "در" -> Color(0xFF8B5E3C)
    kind == "پنجره" -> Color(0xFF397C9B)
    kind == "سینک" -> Color(0xFF527F83)
    kind == "اجاق" -> Color(0xFF7D5555)
    kind == "یخچال" -> Color(0xFF657080)
    else -> Color(0xFF756044)
}

private fun findRoomCollisions(items: List<RoomItem>): List<Pair<String, String>> {
    val result = mutableListOf<Pair<String, String>>()
    for (i in items.indices) for (j in i + 1 until items.size) {
        val a = items[i]; val b = items[j]
        val overlapX = a.x < b.x + b.width && a.x + a.width > b.x
        val overlapY = a.y < b.y + b.depth && a.y + a.depth > b.y
        if (overlapX && overlapY) result += a.name to b.name
    }
    return result
}

@Composable private fun AddRoomItemDialog(onDismiss: () -> Unit, onAdd: (String, String, Int, Int) -> Unit) {
    var name by remember { mutableStateOf("پنجره") }; var kind by remember { mutableStateOf("پنجره") }
    var width by remember { mutableStateOf("900") }; var depth by remember { mutableStateOf("100") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("افزودن جزء آشپزخانه") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("نام") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf("دیوار", "در", "پنجره", "سینک", "اجاق", "یخچال", "ستون").forEach { v -> FilterChip(selected = kind == v, onClick = { kind = v; name = v }, label = { Text(v) }) } }
            OutlinedTextField(width, { width = it.filter(Char::isDigit) }, label = { Text("طول / عرض (mm)") }, singleLine = true)
            OutlinedTextField(depth, { depth = it.filter(Char::isDigit) }, label = { Text("عمق روی نقشه (mm)") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { onAdd(name.ifBlank { kind }, kind, width.toInt(), depth.toInt()) }, enabled = name.isNotBlank() && (width.toIntOrNull() ?: 0) in 50..10000 && (depth.toIntOrNull() ?: 0) in 30..5000) { Text("افزودن") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun RoomSizeDialog(config: RoomConfig, onDismiss: () -> Unit, onSave: (Int, Int) -> Unit) {
    var width by remember { mutableStateOf(config.width.toString()) }; var depth by remember { mutableStateOf(config.depth.toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("ابعاد فضای آشپزخانه") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(width, { width = it.filter(Char::isDigit) }, label = { Text("طول فضا (mm)") })
        OutlinedTextField(depth, { depth = it.filter(Char::isDigit) }, label = { Text("عرض فضا (mm)") })
    } }, confirmButton = { TextButton(onClick = { onSave(width.toInt(), depth.toInt()) }, enabled = (width.toIntOrNull() ?: 0) in 1000..20000 && (depth.toIntOrNull() ?: 0) in 1000..20000) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

private fun saveRoomItems(context: Context, items: List<RoomItem>) {
    val array = JSONArray(); items.forEach { array.put(JSONObject().put("id", it.id).put("name", it.name).put("kind", it.kind).put("x", it.x).put("y", it.y).put("width", it.width).put("depth", it.depth)) }
    context.getSharedPreferences("room_plan_v09", Context.MODE_PRIVATE).edit().putString("items", array.toString()).apply()
}
private fun loadRoomItems(context: Context): List<RoomItem> = runCatching {
    val a = JSONArray(context.getSharedPreferences("room_plan_v09", Context.MODE_PRIVATE).getString("items", "[]") ?: "[]")
    (0 until a.length()).map { val o = a.getJSONObject(it); RoomItem(o.getLong("id"), o.getString("name"), o.getString("kind"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.getInt("width"), o.getInt("depth")) }
}.getOrDefault(emptyList())
private fun saveRoomConfig(context: Context, c: RoomConfig) { context.getSharedPreferences("room_plan_v09", Context.MODE_PRIVATE).edit().putInt("width", c.width).putInt("depth", c.depth).putString("shape", c.shape).apply() }
private fun loadRoomConfig(context: Context) = context.getSharedPreferences("room_plan_v09", Context.MODE_PRIVATE).let { RoomConfig(it.getInt("width", 3600), it.getInt("depth", 3000), it.getString("shape", "مستطیلی") ?: "مستطیلی") }
