package ir.cabinetsaz.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CabinetDao {
    @Query("SELECT * FROM projects ORDER BY createdAt DESC") fun observeProjects(): Flow<List<CabinetProject>>
    @Insert suspend fun insertProject(project: CabinetProject): Long
    @Query("DELETE FROM projects WHERE id = :id") suspend fun deleteProject(id: Long)
    @Query("SELECT * FROM materials ORDER BY category, name") fun observeMaterials(): Flow<List<MaterialItem>>
    @Insert suspend fun insertMaterial(item: MaterialItem): Long
    @Query("DELETE FROM materials WHERE id = :id") suspend fun deleteMaterial(id: Long)
}
