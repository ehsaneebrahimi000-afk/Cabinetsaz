package ir.cabinetsaz.app

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max

class CabinetGLView(context: Context) : GLSurfaceView(context) {
    private val cabinetRenderer = CabinetRenderer()
    private var lastX = 0f
    init {
        setEGLContextClientVersion(2)
        setRenderer(cabinetRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
    fun setDoor(value: Float) { cabinetRenderer.door = value }
    fun setDrawer(value: Float) { cabinetRenderer.drawer = value }
    fun setModules(value: Int) { cabinetRenderer.modules = value.coerceIn(1, 6) }
    fun setDimensions(widthMm: Int, heightMm: Int, depthMm: Int) { cabinetRenderer.scaleX = widthMm.coerceIn(250, 1800) / 600f; cabinetRenderer.scaleY = heightMm.coerceIn(250, 2400) / 720f; cabinetRenderer.scaleZ = depthMm.coerceIn(200, 1200) / 560f }
    fun setWallCabinet(value: Boolean) { cabinetRenderer.wallCabinet = value }
    fun setFinish(value: Int) { cabinetRenderer.finish = value.coerceIn(0, 3) }
    fun setKitchenUnits(value: List<LayoutCabinet>) { cabinetRenderer.sceneUnits = value }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> { lastX = event.x; return true }
            MotionEvent.ACTION_MOVE -> { val dx = event.x - lastX; cabinetRenderer.rotation += dx * 0.5f; lastX = event.x; return true }
        }
        return true
    }
}

private class CabinetRenderer : GLSurfaceView.Renderer {
    @Volatile var rotation = -25f
    @Volatile var door = 0f
    @Volatile var drawer = 0f
    @Volatile var modules = 1
    @Volatile var wallCabinet = false
    @Volatile var finish = 0
    @Volatile var scaleX = 1f
    @Volatile var scaleY = 1f
    @Volatile var scaleZ = 1f
    @Volatile var sceneUnits: List<LayoutCabinet> = emptyList()
    private var program = 0
    private val cube: FloatBuffer = ByteBuffer.allocateDirect(CUBE.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(CUBE); position(0) }
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val vp = FloatArray(16)
    private var pos = 0
    private var mvp = 0
    private var color = 0
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.055f,0.055f,0.065f,1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vertex = "attribute vec4 aPosition; uniform mat4 uMvp; void main(){ gl_Position=uMvp*aPosition; }"
        val fragment = "precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor=uColor; }"
        val vs = shader(GLES20.GL_VERTEX_SHADER, vertex); val fs = shader(GLES20.GL_FRAGMENT_SHADER, fragment)
        program = GLES20.glCreateProgram().also { GLES20.glAttachShader(it,vs); GLES20.glAttachShader(it,fs); GLES20.glLinkProgram(it) }
        pos = GLES20.glGetAttribLocation(program,"aPosition"); mvp = GLES20.glGetUniformLocation(program,"uMvp"); color = GLES20.glGetUniformLocation(program,"uColor")
        Matrix.setLookAtM(view,0,3.3f,2.5f,5.6f,0f,0f,0f,0f,1f,0f)
    }
    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { GLES20.glViewport(0,0,width,height); Matrix.perspectiveM(projection,0,42f,width.toFloat()/max(1,height),0.1f,100f) }
    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)
        Matrix.multiplyMM(vp,0,projection,0,view,0)
        val finishes = arrayOf(floatArrayOf(.72f,.53f,.32f), floatArrayOf(.88f,.86f,.78f), floatArrayOf(.24f,.25f,.27f), floatArrayOf(.42f,.25f,.13f))
        val wood = finishes[finish]
        val units = sceneUnits
        if (units.isEmpty()) {
            val baseY = if (wallCabinet) .55f else -.15f
            val moduleWidth = 1.75f / modules
            for (i in 0 until modules) {
                val x = (i - (modules - 1) / 2f) * 1.9f / modules
                drawCabinet(x, baseY, 0f, moduleWidth, 2.15f, 1.25f, wood)
            }
        } else {
            // The 2D plan and 3D preview consume the same saved unit list.
            val minX = units.minOf { it.x }; val minY = units.minOf { it.y }
            val maxX = units.maxOf { it.x + it.width }; val maxY = units.maxOf { it.y + it.depth }
            val spanX = (maxX - minX).coerceAtLeast(300f)
            val spanZ = (maxY - minY).coerceAtLeast(300f)
            units.forEach { unit ->
                val x = ((unit.x + unit.width / 2f - (minX + maxX) / 2f) / spanX) * 3.2f
                val z = ((unit.y + unit.depth / 2f - (minY + maxY) / 2f) / spanZ) * 2.4f
                val sx = (unit.width / 600f).coerceIn(.45f, 2.2f)
                val sy = (unit.height / 720f).coerceIn(.45f, 2.4f)
                val sz = (unit.depth / 560f).coerceIn(.45f, 1.8f)
                val isWall = unit.type == "دیواری"
                val baseY = if (isWall) .65f else -.45f
                drawCabinet(x, baseY, z, sx, sy, sz, wood)
            }
        }
    }
    private fun drawCabinet(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, wood: FloatArray) {
        val w = .82f * sx; val h = 1.05f * sy; val d = .62f * sz
        draw(x,y,z,w,h,d,0f,.30f,.24f,.18f)
        draw(x-w/2+.035f*sx,y,z,.07f*sx,h,d,0f,.55f,.39f,.22f)
        draw(x+w/2-.035f*sx,y,z,.07f*sx,h,d,0f,.55f,.39f,.22f)
        draw(x,y+h/2-.035f*sy,z,w,.07f*sy,d,0f,.58f,.43f,.27f)
        draw(x,y-h/2+.035f*sy,z,w,.07f*sy,d,0f,.58f,.43f,.27f)
        draw(x,y,z-d/2+.025f,w,h,.05f,0f,.34f,.25f,.18f)
        val doorAngle = door * 100f
        draw(x-w*.25f,y,z+d/2,w*.49f,h*.94f,.045f,doorAngle,wood[0],wood[1],wood[2],pivotX=x-w/2)
        draw(x+w*.25f,y,z+d/2,w*.49f,h*.94f,.045f,-doorAngle,wood[0],wood[1],wood[2],pivotX=x+w/2)
        for (i in 0..2) {
            val dy = y - h*.30f + i*h*.30f
            draw(x,dy,z+d*.18f+drawer*.45f,w*.78f,h*.20f,d*.72f,0f,.40f,.29f,.19f)
            draw(x,dy,z+d*.55f+drawer*.45f,w*.80f,h*.20f,.045f,0f,wood[0],wood[1],wood[2])
        }
    }
    private fun draw(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,angle:Float,r:Float,g:Float,b:Float,pivotX:Float=0f) {
        Matrix.setIdentityM(model,0)
        Matrix.translateM(model,0,x*scaleX,y*scaleY,z*scaleZ)
        if (pivotX != 0f) { Matrix.translateM(model,0,pivotX*scaleX,0f,0f); Matrix.rotateM(model,0,angle,0f,1f,0f); Matrix.translateM(model,0,-pivotX*scaleX,0f,0f) }
        else if (angle != 0f) Matrix.rotateM(model,0,angle,0f,1f,0f)
        Matrix.scaleM(model,0,sx*scaleX,sy*scaleY,sz*scaleZ)
        val temp=FloatArray(16); Matrix.multiplyMM(temp,0,vp,0,model,0)
        GLES20.glUniformMatrix4fv(mvp,1,false,temp,0); GLES20.glUniform4f(color,r,g,b,1f)
        GLES20.glEnableVertexAttribArray(pos); GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,0,cube)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36)
    }
    private fun shader(type:Int, source:String):Int = GLES20.glCreateShader(type).also { GLES20.glShaderSource(it,source); GLES20.glCompileShader(it) }
    companion object {
        private val CUBE = floatArrayOf(
            -0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
            0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f,
            0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,
            -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f
        )
    }
}

private fun loadKitchenScene(context: Context): List<LayoutCabinet> = runCatching {
    val raw = context.getSharedPreferences("kitchen_layout", Context.MODE_PRIVATE).getString("units", "[]") ?: "[]"
    val array = org.json.JSONArray(raw)
    (0 until array.length()).map { i -> val o = array.getJSONObject(i); LayoutCabinet(o.getLong("id"), o.getString("title"), o.getString("type"), o.getInt("width"), o.getInt("height"), o.getInt("depth"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat()) }
}.getOrDefault(emptyList())

@Composable fun CabinetDesignerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("cabinet_designer_v06", Context.MODE_PRIVATE) }
    var door by remember { mutableFloatStateOf(prefs.getFloat("door", 0f)) }
    var drawer by remember { mutableFloatStateOf(prefs.getFloat("drawer", 0f)) }
    var modules by remember { mutableIntStateOf(prefs.getInt("modules", 2).coerceIn(1, 6)) }
    var wall by remember { mutableStateOf(prefs.getBoolean("wall", false)) }
    var finish by remember { mutableIntStateOf(prefs.getInt("finish", 0).coerceIn(0, 3)) }
    var width by remember { mutableStateOf(prefs.getInt("width", 600).toString()) }
    var height by remember { mutableStateOf(prefs.getInt("height", 720).toString()) }
    var depth by remember { mutableStateOf(prefs.getInt("depth", 560).toString()) }
    var message by remember { mutableStateOf("") }
    var view by remember { mutableStateOf<CabinetGLView?>(null) }
    var kitchenUnits by remember { mutableStateOf(loadKitchenScene(context)) }
    LaunchedEffect(Unit) { kitchenUnits = loadKitchenScene(context) }
    LaunchedEffect(kitchenUnits) { view?.setKitchenUnits(kitchenUnits) }
    val w = width.toIntOrNull() ?: 600
    val h = height.toIntOrNull() ?: 720
    val d = depth.toIntOrNull() ?: 560
    val dimensionsValid = w in 250..1800 && h in 250..2400 && d in 200..1200
    LaunchedEffect(w, h, d) { if (dimensionsValid) view?.setDimensions(w, h, d) }
    LaunchedEffect(door, drawer, modules, wall, finish) {
        view?.setDoor(door); view?.setDrawer(drawer); view?.setModules(modules); view?.setWallCabinet(wall); view?.setFinish(finish)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(9.dp)) {
        Text("نمای سه‌بعدی چیدمان", style=MaterialTheme.typography.titleLarge)
        Text("این نما از همان یونیت‌های ذخیره‌شده در بخش چیدمان استفاده می‌کند؛ برای تازه‌سازی، صفحه را دوباره باز کنید.", style=MaterialTheme.typography.bodySmall)
        Text("ابعاد ورودی مستقیماً مقیاس مدل را تغییر می‌دهد. برای چرخش، انگشت را روی مدل بکشید.", style=MaterialTheme.typography.bodySmall)
        AndroidView(factory={ ctx -> CabinetGLView(ctx).also { gl -> view=gl; gl.setModules(modules); gl.setWallCabinet(wall); gl.setFinish(finish); gl.setDoor(door); gl.setDrawer(drawer); gl.setKitchenUnits(kitchenUnits); if(dimensionsValid) gl.setDimensions(w,h,d) } }, modifier=Modifier.fillMaxWidth().height(300.dp))
        Text("تعداد یونیت: $modules")
        Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick={ modules=(modules-1).coerceAtLeast(1) }, enabled=modules>1) { Text("−") }
            Text("$modules یونیت", modifier=Modifier.weight(1f))
            OutlinedButton(onClick={ modules=(modules+1).coerceAtMost(6) }, enabled=modules<6) { Text("+") }
            FilterChip(selected=wall,onClick={wall=true},label={Text("دیواری")})
            FilterChip(selected=!wall,onClick={wall=false},label={Text("زمینی")})
        }
        Text("ابعاد هر یونیت (میلی‌متر)", style=MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(width,{width=it.filter(Char::isDigit).take(4)},label={Text("عرض")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(height,{height=it.filter(Char::isDigit).take(4)},label={Text("ارتفاع")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(depth,{depth=it.filter(Char::isDigit).take(4)},label={Text("عمق")},modifier=Modifier.weight(1f),singleLine=true)
        }
        if (!dimensionsValid) Text("محدوده مجاز: عرض ۲۵۰ تا ۱۸۰۰، ارتفاع ۲۵۰ تا ۲۴۰۰ و عمق ۲۰۰ تا ۱۲۰۰ میلی‌متر.", color=MaterialTheme.colorScheme.error, style=MaterialTheme.typography.bodySmall)
        Text("رنگ و روکش")
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("چوب روشن","سفید","ذغالی","گردویی").forEachIndexed { i,label -> FilterChip(selected=finish==i,onClick={finish=i},label={Text(label)}) }
        }
        Text("بازشدن درب‌ها: ${(door*100).toInt()}٪")
        Slider(value=door,onValueChange={door=it},valueRange=0f..1f)
        Text("بیرون‌آمدن کشوها: ${(drawer*100).toInt()}٪")
        Slider(value=drawer,onValueChange={drawer=it},valueRange=0f..1f)
        Button(onClick={
            prefs.edit().putInt("modules",modules).putBoolean("wall",wall).putInt("finish",finish)
                .putInt("width",w).putInt("height",h).putInt("depth",d).putFloat("door",door).putFloat("drawer",drawer).apply()
            message="طرح روی همین گوشی ذخیره شد."
        }, enabled=dimensionsValid, modifier=Modifier.fillMaxWidth()) { Text("ذخیره طرح روی گوشی") }
        if(message.isNotBlank()) Text(message, color=MaterialTheme.colorScheme.primary)
        OutlinedButton(onClick={
            door=0f; drawer=0f; modules=1; wall=false; finish=0; width="600"; height="720"; depth="560"
            prefs.edit().clear().apply(); message="طرح به تنظیمات اولیه برگشت."
        }, modifier=Modifier.fillMaxWidth()) { Text("بازنشانی طراح") }
        Text("توجه: این نسخه پیش‌نمایش پارامتریک است؛ ابعاد هندسه را مقیاس می‌دهند اما جزئیات ساخت، ضخامت واقعی همه قطعات، لقی درب و اتصالات هنوز نقشه اجرایی صنعتی محسوب نمی‌شوند.", style=MaterialTheme.typography.bodySmall)
    }
}
