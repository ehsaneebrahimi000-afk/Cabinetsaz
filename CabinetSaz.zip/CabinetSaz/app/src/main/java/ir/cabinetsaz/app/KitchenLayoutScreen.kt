package ir.cabinetsaz.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

internal data class LayoutCabinet(
    val id: Long, val title: String, val type: String,
    val width: Int, val height: Int, val depth: Int,
    val x: Float, val y: Float
)

@Composable
fun KitchenLayoutScreen() {
    val context = LocalContext.current
    var units by remember { mutableStateOf(loadLayout(context)) }
    var selected by remember { mutableStateOf<Long?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showEdit by remember { mutableStateOf(false) }
    val latestUnits by rememberUpdatedState(units)
    val active = units.firstOrNull { it.id == selected }
    fun persist(next: List<LayoutCabinet>) { units = next; saveLayout(context, next) }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("طراحی آزاد آشپزخانه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("نمای بالا • جابه‌جایی با کشیدن انگشت • ذخیره خودکار", style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Text("افزودن") }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202025))) {
            Column(Modifier.padding(10.dp)) {
                Text("نقشه چیدمان", color = Color(0xFFD4AF37), fontWeight = FontWeight.Bold)
                BoxWithConstraints(Modifier.fillMaxWidth().height(300.dp).background(Color(0xFF151519), RoundedCornerShape(10.dp))) {
                    val maxX = (maxWidth - 92.dp).coerceAtLeast(0.dp)
                    val maxY = (maxHeight - 62.dp).coerceAtLeast(0.dp)
                    // Grid is a visual planning aid; dimensions are entered in millimetres below.
                    for (i in 1..5) {
                        Box(Modifier.offset(x = maxWidth * (i / 6f), y = 0.dp).width(1.dp).height(maxHeight).background(Color(0xFF29292F)))
                        Box(Modifier.offset(x = 0.dp, y = maxHeight * (i / 6f)).height(1.dp).width(maxWidth).background(Color(0xFF29292F)))
                    }
                    units.forEach { unit ->
                        val isSelected = unit.id == selected
                        Column(
                            Modifier.offset { IntOffset(unit.x.roundToInt(), unit.y.roundToInt()) }
                                .size(width = 88.dp, height = 58.dp)
                                .background(if (isSelected) Color(0xFFD4AF37) else Color(0xFF756044), RoundedCornerShape(7.dp))
                                .clickable { selected = unit.id }
                                .pointerInput(unit.id, maxX, maxY) {
                                    detectDragGestures { change, drag ->
                                        change.consume()
                                        val nx = (unit.x + drag.x).coerceIn(0f, maxX.toPx())
                                        val ny = (unit.y + drag.y).coerceIn(0f, maxY.toPx())
                                        persist(latestUnits.map { if (it.id == unit.id) it.copy(x = nx, y = ny) else it })
                                        selected = unit.id
                                    }
                                }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                        ) {
                            Text(unit.title, color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text("${unit.width}×${unit.depth}", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    if (units.isEmpty()) Box(Modifier.align(Alignment.Center)) { Text("برای شروع، کابینت اضافه کنید", color = Color.LightGray) }
                }
                Text("راهنما: هر مستطیل یک یونیت است. آن را لمس و نگه دارید و به محل دلخواه بکشید.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 7.dp))
            }
        }
        if (active != null) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202025))) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${active.title} • ${active.type}", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        TextButton(onClick = { showEdit = true }) { Text("ویرایش ابعاد") }
                        IconButton(onClick = { persist(units.filterNot { it.id == active.id }); selected = null }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFE57373)) }
                    }
                    Text("عرض ${active.width} • ارتفاع ${active.height} • عمق ${active.depth} میلی‌متر", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text("یونیت‌های طرح (${units.size})", fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(units, key = { it.id }) { unit ->
                TextButton(onClick = { selected = unit.id }, modifier = Modifier.fillMaxWidth()) {
                    Text("${unit.title}  |  ${unit.type}  |  ${unit.width}×${unit.height}×${unit.depth} mm", modifier = Modifier.weight(1f))
                    if (selected == unit.id) Text("انتخاب‌شده", color = Color(0xFFD4AF37))
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Save, null, tint = Color(0xFFD4AF37))
            Spacer(Modifier.width(6.dp)); Text("چیدمان روی همین گوشی ذخیره می‌شود.", style = MaterialTheme.typography.bodySmall)
        }
    }
    if (showAdd) AddLayoutCabinetDialog(onDismiss = { showAdd = false }) { title, type, w, h, d ->
        val new = LayoutCabinet(System.currentTimeMillis(), title, type, w, h, d, 12f + (units.size % 3) * 94f, 12f + (units.size / 3) * 68f)
        persist(units + new); selected = new.id; showAdd = false
    }
    if (showEdit && active != null) EditLayoutCabinetDialog(active, onDismiss = { showEdit = false }) { w, h, d ->
        persist(units.map { if (it.id == active.id) it.copy(width = w, height = h, depth = d) else it }); showEdit = false
    }
}

@Composable
private fun AddLayoutCabinetDialog(onDismiss: () -> Unit, onAdd: (String, String, Int, Int, Int) -> Unit) {
    var title by remember { mutableStateOf("کابینت ${System.currentTimeMillis().toString().takeLast(4)}") }
    var type by remember { mutableStateOf("زمینی") }
    var width by remember { mutableStateOf("600") }; var height by remember { mutableStateOf("720") }; var depth by remember { mutableStateOf("560") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("افزودن یونیت") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("نام یونیت") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("زمینی", "دیواری", "کشویی", "ایستاده").forEach { label -> FilterChip(selected = type == label, onClick = { type = label }, label = { Text(label) }) }
            }
            OutlinedTextField(width, { width = it.filter(Char::isDigit) }, label = { Text("عرض (mm)") }, singleLine = true)
            OutlinedTextField(height, { height = it.filter(Char::isDigit) }, label = { Text("ارتفاع (mm)") }, singleLine = true)
            OutlinedTextField(depth, { depth = it.filter(Char::isDigit) }, label = { Text("عمق (mm)") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { onAdd(title.ifBlank { "یونیت" }, type, width.toInt(), height.toInt(), depth.toInt()) }, enabled = title.isNotBlank() && (width.toIntOrNull() ?: 0) in 100..3000 && (height.toIntOrNull() ?: 0) in 100..3000 && (depth.toIntOrNull() ?: 0) in 100..1500) { Text("افزودن") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable
private fun EditLayoutCabinetDialog(unit: LayoutCabinet, onDismiss: () -> Unit, onSave: (Int, Int, Int) -> Unit) {
    var width by remember(unit.id) { mutableStateOf(unit.width.toString()) }; var height by remember(unit.id) { mutableStateOf(unit.height.toString()) }; var depth by remember(unit.id) { mutableStateOf(unit.depth.toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("ویرایش ابعاد ${unit.title}") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(width, { width = it.filter(Char::isDigit) }, label = { Text("عرض (mm)") })
            OutlinedTextField(height, { height = it.filter(Char::isDigit) }, label = { Text("ارتفاع (mm)") })
            OutlinedTextField(depth, { depth = it.filter(Char::isDigit) }, label = { Text("عمق (mm)") })
        }
    }, confirmButton = { TextButton(onClick = { onSave(width.toInt(), height.toInt(), depth.toInt()) }, enabled = (width.toIntOrNull() ?: 0) in 100..3000 && (height.toIntOrNull() ?: 0) in 100..3000 && (depth.toIntOrNull() ?: 0) in 100..1500) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

private fun saveLayout(context: Context, units: List<LayoutCabinet>) {
    val array = JSONArray()
    units.forEach { u -> array.put(JSONObject().put("id", u.id).put("title", u.title).put("type", u.type).put("width", u.width).put("height", u.height).put("depth", u.depth).put("x", u.x).put("y", u.y)) }
    context.getSharedPreferences("kitchen_layout", Context.MODE_PRIVATE).edit().putString("units", array.toString()).apply()
}

private fun loadLayout(context: Context): List<LayoutCabinet> = runCatching {
    val raw = context.getSharedPreferences("kitchen_layout", Context.MODE_PRIVATE).getString("units", "[]") ?: "[]"
    val array = JSONArray(raw)
    (0 until array.length()).map { i -> val o = array.getJSONObject(i); LayoutCabinet(o.getLong("id"), o.getString("title"), o.getString("type"), o.getInt("width"), o.getInt("height"), o.getInt("depth"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat()) }
}.getOrDefault(emptyList())
