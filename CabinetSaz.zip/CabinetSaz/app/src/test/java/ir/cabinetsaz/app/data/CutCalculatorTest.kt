package ir.cabinetsaz.app.data

import org.junit.Assert.*
import org.junit.Test

class CutCalculatorTest {
    @Test fun calculatesBasicCabinet() {
        val result = CutCalculator.calculate(CutInput(600, 720, 560, 16, 1, 2, true))
        assertNotNull(result)
        assertEquals(7, result!!.totalPieces)
        assertEquals(4, result.estimatedHinges)
        assertTrue(result.totalAreaSquareMetres > 1.0)
        assertTrue(result.edgeBandingMetres > 0.0)
    }

    @Test fun rejectsInvalidDimensions() {
        assertNull(CutCalculator.calculate(CutInput(20, 720, 560, 16, 1, 2, true)))
        assertNull(CutCalculator.calculate(CutInput(600, 720, 560, 50, 1, 2, true)))
    }

    @Test fun supportsNoDoorsAndNoShelves() {
        val result = CutCalculator.calculate(CutInput(600, 720, 560, 16, 0, 0, false))
        assertNotNull(result)
        assertEquals(4, result!!.totalPieces)
        assertEquals(0, result.estimatedHinges)
    }
}
